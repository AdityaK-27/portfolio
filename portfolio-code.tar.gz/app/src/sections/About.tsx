import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Code2, 
  Brain, 
  Database, 
  BarChart3, 
  Cloud, 
  Server 
} from 'lucide-react';
import { useReducedMotion } from '@/hooks';

gsap.registerPlugin(ScrollTrigger);

const skillCategories = [
  {
    id: 'programming',
    title: 'Programming',
    icon: Code2,
    skills: ['Python', 'SQL (advanced joins, subqueries, window functions)'],
  },
  {
    id: 'ai-ml',
    title: 'AI & ML',
    icon: Brain,
    skills: ['TensorFlow', 'LSTM', 'OpenCV', 'MediaPipe', 'LangChain', 'Prompt Engineering'],
  },
  {
    id: 'data-science',
    title: 'Data Science',
    icon: Database,
    skills: ['Pandas', 'NumPy', 'Scikit-learn', 'ETL pipelines'],
  },
  {
    id: 'bi-analytics',
    title: 'BI & Analytics',
    icon: BarChart3,
    skills: ['Power BI (DAX)', 'Tableau', 'IBM Cognos', 'Business Reporting'],
  },
  {
    id: 'big-data',
    title: 'Big Data & Cloud',
    icon: Cloud,
    skills: ['Hadoop', 'Apache Spark', 'Azure Blob Storage', 'AWS S3'],
  },
  {
    id: 'databases',
    title: 'Databases',
    icon: Server,
    skills: ['PostgreSQL', 'MySQL', 'SQL Server', 'SSMS'],
  },
];

export function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const paragraphsRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion || !sectionRef.current) return;

    const ctx = gsap.context(() => {
      // Heading animation
      const words = headingRef.current?.querySelectorAll('.word');
      if (words) {
        gsap.fromTo(
          words,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.05,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: headingRef.current,
              start: 'top 85%',
              once: true,
            },
          }
        );
      }

      // Paragraphs animation
      const paragraphs = paragraphsRef.current?.querySelectorAll('p');
      if (paragraphs) {
        gsap.fromTo(
          paragraphs,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            stagger: 0.15,
            ease: 'smooth',
            scrollTrigger: {
              trigger: paragraphsRef.current,
              start: 'top 85%',
              once: true,
            },
          }
        );
      }

      // Skill cards animation
      const cards = skillsRef.current?.querySelectorAll('.skill-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { scale: 0.9, y: 40, opacity: 0 },
          {
            scale: 1,
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'elastic.out(1, 0.5)',
            scrollTrigger: {
              trigger: skillsRef.current,
              start: 'top 85%',
              once: true,
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, [prefersReducedMotion]);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative py-24 lg:py-32"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="mb-16">
          <span className="text-accent text-sm font-medium uppercase tracking-wider mb-4 block">
            About Me
          </span>
          <h2
            ref={headingRef}
            className="text-3xl sm:text-4xl lg:text-5xl font-heading font-medium text-white max-w-3xl"
          >
            <span className="word inline-block">Passionate</span>{' '}
            <span className="word inline-block">about</span>{' '}
            <span className="word inline-block">turning</span>{' '}
            <span className="word inline-block">data</span>{' '}
            <span className="word inline-block">into</span>{' '}
            <span className="word inline-block text-accent">impact</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left column - About text */}
          <div ref={paragraphsRef} className="space-y-6">
            <p className="text-gray-400 text-lg leading-relaxed">
              I'm a Data Engineer and Analyst with experience at Reliance Industries Ltd., 
              where I developed Power BI dashboards that improved reporting speed by 30% 
              and built 20+ DAX measures for business KPIs.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed">
              My expertise spans the full data stack—from SQL and ETL pipelines to 
              machine learning and AI applications. I enjoy solving complex problems 
              and creating solutions that drive business value.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed">
              With a strong foundation in both engineering and analytics, I bridge the 
              gap between raw data and meaningful insights that help organizations make 
              better decisions.
            </p>
          </div>

          {/* Right column - Skills */}
          <div ref={skillsRef} className="grid sm:grid-cols-2 gap-4">
            {skillCategories.map((category) => {
              const Icon = category.icon;
              return (
                <div
                  key={category.id}
                  className="skill-card group p-5 rounded-xl bg-dark-card border border-dark-border transition-all duration-300 ease-expo-out hover:border-accent hover:-translate-y-2 hover:shadow-card-hover"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors duration-300">
                      <Icon className="w-5 h-5 text-accent" />
                    </div>
                    <h3 className="text-white font-medium">{category.title}</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill) => (
                      <span
                        key={skill}
                        className="text-xs px-2.5 py-1 rounded-full bg-dark-secondary border border-dark-border text-gray-400 group-hover:border-accent/30 transition-colors duration-200"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
