import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Phone, MapPin, Linkedin, Github, BarChart3, Table2 } from 'lucide-react';
import { useReducedMotion } from '@/hooks';

gsap.registerPlugin(ScrollTrigger);

const contactInfo = [
  { icon: Mail, label: 'Email', value: 'aditya27kankarwal@gmail.com', href: 'mailto:aditya27kankarwal@gmail.com' },
  { icon: Phone, label: 'Phone', value: '+91 7016636155', href: 'tel:+917016636155' },
  { icon: MapPin, label: 'Location', value: 'Chennai, India', href: '#' },
];

const socialLinks = [
  { icon: Linkedin, label: 'LinkedIn', href: 'https://linkedin.com' },
  { icon: Github, label: 'GitHub', href: 'https://github.com' },
  { icon: BarChart3, label: 'Portfolio', href: '#' },
  { icon: Table2, label: 'Tableau', href: '#' },
];

export function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion || !sectionRef.current) return;

    const ctx = gsap.context(() => {
      // Headline gradient reveal
      gsap.fromTo(
        headlineRef.current,
        { backgroundPosition: '200% center', opacity: 0 },
        {
          backgroundPosition: '0% center',
          opacity: 1,
          duration: 1.2,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 85%',
            once: true,
          },
        }
      );

      // Content stagger
      const items = contentRef.current?.querySelectorAll('.contact-item');
      if (items) {
        gsap.fromTo(
          items,
          { y: 20, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 85%',
              once: true,
            },
          }
        );
      }

      // Social links
      const socials = contentRef.current?.querySelectorAll('.social-link');
      if (socials) {
        gsap.fromTo(
          socials,
          { scale: 0.8, opacity: 0 },
          {
            scale: 1,
            opacity: 1,
            duration: 0.4,
            stagger: 0.08,
            ease: 'elastic.out(1, 0.5)',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 80%',
              once: true,
            },
          }
        );
      }

      // CTA button
      const cta = contentRef.current?.querySelector('.cta-button');
      if (cta) {
        gsap.fromTo(
          cta,
          { scale: 0.9, opacity: 0 },
          {
            scale: 1,
            opacity: 1,
            duration: 0.6,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: cta,
              start: 'top 90%',
              once: true,
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, [prefersReducedMotion]);

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative py-24 lg:py-32"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-accent/5 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Headline */}
        <h2
          ref={headlineRef}
          className="text-4xl sm:text-5xl lg:text-6xl font-heading font-semibold mb-6 bg-gradient-to-r from-white via-accent to-white bg-[length:200%_auto] bg-clip-text text-transparent"
          style={{ backgroundPosition: '200% center' }}
        >
          Let's work together
        </h2>

        <p className="text-xl text-gray-400 mb-12">
          Have a project in mind? I'd love to hear about it.
        </p>

        <div ref={contentRef}>
          {/* Contact info */}
          <div className="flex flex-wrap justify-center gap-6 mb-10">
            {contactInfo.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="contact-item group flex items-center gap-3 px-5 py-3 rounded-xl bg-dark-card border border-dark-border transition-all duration-200 ease-smooth hover:border-accent hover:bg-white/5"
              >
                <item.icon className="w-5 h-5 text-gray-400 group-hover:text-accent group-hover:scale-110 transition-all duration-200" />
                <span className="text-gray-300 group-hover:text-white group-hover:translate-x-1 transition-all duration-200">
                  {item.value}
                </span>
              </a>
            ))}
          </div>

          {/* Social links */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {socialLinks.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="social-link group flex items-center gap-2 px-4 py-2.5 border border-dark-border rounded-lg bg-transparent transition-all duration-200 ease-smooth hover:border-accent hover:bg-white/5 hover:-translate-y-1"
              >
                <social.icon className="w-4 h-4 text-white group-hover:text-accent transition-colors duration-200" />
                <span className="text-sm text-white group-hover:text-accent transition-colors duration-200">
                  {social.label}
                </span>
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <a
            href="mailto:aditya27kankarwal@gmail.com"
            className="cta-button inline-flex items-center gap-2 px-8 py-4 bg-white text-dark font-heading font-medium rounded-lg transition-all duration-300 ease-expo-out hover:bg-accent hover:text-white hover:scale-105 hover:shadow-glow-strong animate-pulse-glow"
          >
            <Mail className="w-5 h-5" />
            Get in Touch
          </a>
        </div>
      </div>
    </section>
  );
}
