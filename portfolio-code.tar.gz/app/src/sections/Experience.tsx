import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Calendar, Briefcase } from 'lucide-react';
import { useReducedMotion } from '@/hooks';

gsap.registerPlugin(ScrollTrigger);

const experiences = [
  {
    id: 'reliance',
    role: 'Data Analytics Vocational Trainee',
    company: 'Reliance Industries Ltd.',
    location: 'Jamnagar',
    duration: 'Sept 2022 – Dec 2025',
    type: 'On-site',
    achievements: [
      'Developed Power BI dashboard to support business reporting needs, replicating an internal Angular app and improving report speed by 30% using DirectQuery with SQL Server.',
      'Converted 15+ stored procedures into SQL views and built 20+ DAX measures to track and automate business KPIs, improving data accuracy for reporting.',
    ],
    techStack: ['Power BI', 'SQL Server', 'SSMS', 'DAX'],
  },
];

export function Experience() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion || !sectionRef.current) return;

    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { clipPath: 'inset(0 50% 0 50%)' },
        {
          clipPath: 'inset(0 0% 0 0%)',
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 85%',
            once: true,
          },
        }
      );

      // Timeline line animation
      const timelineLine = timelineRef.current?.querySelector('.timeline-line');
      if (timelineLine) {
        gsap.fromTo(
          timelineLine,
          { scaleY: 0 },
          {
            scaleY: 1,
            duration: 1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: timelineRef.current,
              start: 'top 80%',
              once: true,
            },
          }
        );
      }

      // Experience card animation
      const cards = timelineRef.current?.querySelectorAll('.experience-card');
      if (cards) {
        cards.forEach((card, index) => {
          const isLeft = index % 2 === 0;
          gsap.fromTo(
            card,
            { 
              x: isLeft ? -80 : 80, 
              rotateY: isLeft ? 15 : -15, 
              opacity: 0 
            },
            {
              x: 0,
              rotateY: 0,
              opacity: 1,
              duration: 0.7,
              ease: 'expo.out',
              scrollTrigger: {
                trigger: card,
                start: 'top 85%',
                once: true,
              },
            }
          );
        });
      }

      // Timeline nodes animation
      const nodes = timelineRef.current?.querySelectorAll('.timeline-node');
      if (nodes) {
        gsap.fromTo(
          nodes,
          { scale: 0 },
          {
            scale: 1,
            duration: 0.4,
            ease: 'elastic.out(1, 0.5)',
            stagger: 0.2,
            scrollTrigger: {
              trigger: timelineRef.current,
              start: 'top 80%',
              once: true,
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, [prefersReducedMotion]);

  return (
    <section
      ref={sectionRef}
      id="experience"
      className="relative py-24 lg:py-32"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="text-accent text-sm font-medium uppercase tracking-wider mb-4 block">
            Experience
          </span>
          <h2
            ref={titleRef}
            className="text-3xl sm:text-4xl lg:text-5xl font-heading font-medium text-white"
          >
            Work Experience
          </h2>
        </div>

        {/* Timeline */}
        <div ref={timelineRef} className="relative">
          {/* Timeline line - hidden on mobile */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2">
            <div 
              className="timeline-line absolute inset-0 bg-gradient-to-b from-accent via-accent/50 to-transparent origin-top"
              style={{ transform: 'scaleY(0)' }}
            />
          </div>

          {/* Experience items */}
          <div className="space-y-12 lg:space-y-0">
            {experiences.map((exp, index) => (
              <div
                key={exp.id}
                className={`relative lg:grid lg:grid-cols-2 lg:gap-8 ${
                  index % 2 === 0 ? '' : 'lg:direction-rtl'
                }`}
                style={{ perspective: '800px' }}
              >
                {/* Timeline node - hidden on mobile */}
                <div className="hidden lg:flex absolute left-1/2 top-8 -translate-x-1/2 z-10">
                  <div className="timeline-node w-4 h-4 rounded-full bg-accent animate-timeline-pulse" />
                </div>

                {/* Card */}
                <div
                  className={`experience-card ${
                    index % 2 === 0 
                      ? 'lg:col-start-1 lg:pr-12' 
                      : 'lg:col-start-2 lg:pl-12'
                  }`}
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  <div className="p-6 lg:p-8 rounded-2xl bg-dark-card border border-dark-border transition-all duration-300 ease-expo-out hover:border-accent hover:shadow-card-hover group">
                    {/* Header */}
                    <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                      <div>
                        <h3 className="text-xl font-heading font-medium text-white mb-1 group-hover:text-accent transition-colors duration-300">
                          {exp.role}
                        </h3>
                        <div className="flex items-center gap-2 text-gray-400">
                          <Briefcase className="w-4 h-4" />
                          <span>{exp.company}</span>
                        </div>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-accent/10 text-accent text-xs font-medium">
                        {exp.type}
                      </span>
                    </div>

                    {/* Meta info */}
                    <div className="flex flex-wrap gap-4 mb-6 text-sm text-gray-500">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-4 h-4" />
                        <span>{exp.duration}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-4 h-4" />
                        <span>{exp.location}</span>
                      </div>
                    </div>

                    {/* Achievements */}
                    <ul className="space-y-3 mb-6">
                      {exp.achievements.map((achievement, i) => (
                        <li
                          key={i}
                          className="flex items-start gap-3 text-gray-400 text-sm leading-relaxed"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-accent mt-2 flex-shrink-0 group-hover:bg-white transition-colors duration-200" />
                          <span className="group-hover:translate-x-1 transition-transform duration-200">
                            {achievement}
                          </span>
                        </li>
                      ))}
                    </ul>

                    {/* Tech stack */}
                    <div className="flex flex-wrap gap-2">
                      {exp.techStack?.map((tech) => (
                        <span
                          key={tech}
                          className="text-xs px-3 py-1 rounded-full bg-dark-secondary border border-dark-border text-gray-400"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Empty space for alternating layout */}
                {index % 2 === 0 ? (
                  <div className="hidden lg:block" />
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
