import { Linkedin, Github, BarChart3, Table2 } from 'lucide-react';

interface SocialButtonProps {
  platform: 'linkedin' | 'github' | 'portfolio' | 'tableau';
  url: string;
  showLabel?: boolean;
}

const platformConfig = {
  linkedin: {
    label: 'LinkedIn',
    icon: Linkedin,
  },
  github: {
    label: 'GitHub',
    icon: Github,
  },
  portfolio: {
    label: 'Portfolio',
    icon: BarChart3,
  },
  tableau: {
    label: 'Tableau',
    icon: Table2,
  },
};

export function SocialButton({ platform, url, showLabel = true }: SocialButtonProps) {
  const config = platformConfig[platform];
  const Icon = config.icon;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="group flex items-center gap-2 px-4 py-2.5 border border-dark-border rounded-lg bg-transparent transition-all duration-200 ease-smooth hover:border-accent hover:bg-white/5 hover:-translate-y-1"
    >
      <Icon className="w-4 h-4 text-white group-hover:text-accent transition-colors duration-200" />
      {showLabel && (
        <span className="text-sm text-white group-hover:text-accent transition-colors duration-200">
          {config.label}
        </span>
      )}
    </a>
  );
}
