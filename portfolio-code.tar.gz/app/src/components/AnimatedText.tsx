import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { useReducedMotion } from '@/hooks';

interface AnimatedTextProps {
  text: string;
  className?: string;
  delay?: number;
  staggerDelay?: number;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span';
  animation?: 'words' | 'chars' | 'lines';
}

export function AnimatedText({
  text,
  className = '',
  delay = 0,
  staggerDelay = 0.05,
  as: Component = 'span',
  animation = 'words',
}: AnimatedTextProps) {
  const containerRef = useRef<HTMLElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion || !containerRef.current) return;

    const container = containerRef.current;
    const elements = container.querySelectorAll('.animate-item');

    gsap.set(elements, { y: 40, opacity: 0, rotateX: -40 });

    gsap.to(elements, {
      y: 0,
      opacity: 1,
      rotateX: 0,
      duration: 1,
      stagger: staggerDelay,
      delay,
      ease: 'expo.out',
    });
  }, [delay, staggerDelay, prefersReducedMotion]);

  const splitText = () => {
    if (animation === 'words') {
      return text.split(' ').map((word, i) => (
        <span
          key={i}
          className="animate-item inline-block mr-[0.25em]"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {word}
        </span>
      ));
    }
    return text.split('').map((char, i) => (
      <span
        key={i}
        className="animate-item inline-block"
        style={{ transformStyle: 'preserve-3d' }}
      >
        {char === ' ' ? '\u00A0' : char}
      </span>
    ));
  };

  return (
    <Component
      ref={containerRef as React.RefObject<HTMLHeadingElement & HTMLParagraphElement & HTMLSpanElement>}
      className={`${className}`}
      style={{ perspective: '1000px' }}
    >
      {splitText()}
    </Component>
  );
}
