import { useEffect, useRef, type ReactNode } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks';

gsap.registerPlugin(ScrollTrigger);

interface FadeInSectionProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
  duration?: number;
  distance?: number;
}

export function FadeInSection({
  children,
  className = '',
  delay = 0,
  direction = 'up',
  duration = 0.8,
  distance = 40,
}: FadeInSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion || !sectionRef.current) return;

    const section = sectionRef.current;
    
    const getDirectionValues = () => {
      switch (direction) {
        case 'up': return { y: distance, x: 0 };
        case 'down': return { y: -distance, x: 0 };
        case 'left': return { x: distance, y: 0 };
        case 'right': return { x: -distance, y: 0 };
        default: return { y: distance, x: 0 };
      }
    };

    const { x, y } = getDirectionValues();

    gsap.set(section, { opacity: 0, x, y });

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 85%',
      onEnter: () => {
        gsap.to(section, {
          opacity: 1,
          x: 0,
          y: 0,
          duration,
          delay,
          ease: 'expo.out',
        });
      },
      once: true,
    });

    return () => {
      trigger.kill();
    };
  }, [delay, direction, duration, distance, prefersReducedMotion]);

  return (
    <div ref={sectionRef} className={className}>
      {children}
    </div>
  );
}
