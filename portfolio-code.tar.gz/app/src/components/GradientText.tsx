import { type ReactNode } from 'react';

interface GradientTextProps {
  children: ReactNode;
  className?: string;
}

export function GradientText({ children, className = '' }: GradientTextProps) {
  return (
    <span
      className={`bg-gradient-to-r from-white via-accent to-white bg-[length:200%_auto] bg-clip-text text-transparent animate-[gradient-shift_5s_ease_infinite] ${className}`}
    >
      {children}
    </span>
  );
}
